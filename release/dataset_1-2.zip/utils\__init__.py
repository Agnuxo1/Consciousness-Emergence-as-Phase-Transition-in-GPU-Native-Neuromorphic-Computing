"""
Utilities for Experiment 1: CPU Reference and Helper Functions

This package contains CPU baseline implementations and validation utilities.
"""

__version__ = "1.0.0"
